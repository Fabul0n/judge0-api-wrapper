# Judge0-API-wrapper

Обёртка для API сервиса Judge0.

## Установка
```bash
pip install judge0-api-wrapper