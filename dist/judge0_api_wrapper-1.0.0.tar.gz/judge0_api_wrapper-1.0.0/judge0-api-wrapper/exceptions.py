class LanguageNotFound(Exception):
    pass

class NotProcessed(Exception):
    pass